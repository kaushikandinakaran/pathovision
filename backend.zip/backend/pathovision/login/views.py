from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate
from django.contrib.auth.forms import UserCreationForm



def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(username, password)
        
        user = authenticate(username=username, password=password)
        print(user is not None)
        if user is not None:
            # User is authenticated, perform data fetching or redirect to another page
            # Example: data fetching
            # data = SomeModel.objects.filter(user=user)
            # return render(request, 'dashboard.html', {'data': data})
            print("hi i am at dashboard")
            return redirect('dashboard')
        else:
            print("something is wrong")
            # Authentication failed, display error message or redirect to login page
            return render(request, 'login.html', {'error': 'Invalid username or password'})
    else:
        return render(request, 'login.html')
    



def signup(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
    
        if form.is_valid():
            form.save()
            print("hi")
            # Redirect to the login page after successful signup
            return redirect('login')
        else :
            print('bye')

    else:
        form = UserCreationForm()
        
    return render(request, 'signup.html', {'form': form})
