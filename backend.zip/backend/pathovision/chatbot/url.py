# chatbot_app/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('chatbot/', views.chatbot_page, name='chatbot'),
    path('upload/', views.upload_image, name='upload'),
]




